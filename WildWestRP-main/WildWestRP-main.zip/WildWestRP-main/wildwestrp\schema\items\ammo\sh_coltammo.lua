
ITEM.name = ".45 Colt Ammo"
ITEM.model = "models/items/357ammo.mdl"
ITEM.price = 0
ITEM.ammo = "ent_ww_ammo_45colt" // type of the ammo
ITEM.ammoAmount = 20 // amount of the ammo
ITEM.ammoDesc = "A Box that contains %s of Colt Ammo."
ITEM.category = "Ammunition"
ITEM.flag = "y"
ITEM.factions = {FACTION_SHERIFF}