ITEM.name = "Vigilante Outfit"
ITEM.desc = "Blue shirt, black vest and brown pants."
ITEM.outfitCategory = "outfit"
ITEM.category = "Clothes"
ITEM.price = 50
ITEM.flag = "d"
ITEM.model = "models/props_c17/BriefCase001a.mdl"
ITEM.replacement = "models/fof/vigilante/vigilante.mdl"
