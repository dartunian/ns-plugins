
ITEM.name = ".40-44 Winchester Shells"
ITEM.price = 5
ITEM.model = "models/Items/BoxBuckshot.mdl"
ITEM.ammo = "ent_ww_ammo_4440" // type of the ammo
ITEM.ammoAmount = 22 // amount of the ammo
ITEM.ammoDesc = "A Box of %s Winchester Shells."
ITEM.category = "Ammunition"
ITEM.flag = "y"