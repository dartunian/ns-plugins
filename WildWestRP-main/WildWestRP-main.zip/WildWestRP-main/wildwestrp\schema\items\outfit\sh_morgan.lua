ITEM.name = "Cowboy Outfit No. 3"
ITEM.desc = "Blue shirt and green pants."
ITEM.outfitCategory = "outfit"
ITEM.category = "Clothes"
ITEM.price = 80
ITEM.flag = "Y"
ITEM.model = "models/props_c17/BriefCase001a.mdl"
ITEM.replacement = "models/newarthurmorgan/newarthurmorganpm.mdl"
