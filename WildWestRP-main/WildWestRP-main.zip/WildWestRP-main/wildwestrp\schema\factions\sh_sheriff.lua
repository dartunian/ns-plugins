FACTION.name = "Sheriff"
FACTION.desc = "There's a new sheriff in town partner!"
FACTION.color = Color(25, 30, 180)
FACTION.isDefault = false
--FACTION.limit = 0.25
FACTION.models = {
	"models/fof/ranger/ranger.mdl"
}
FACTION.weapons = {"weapon_fof_peacemaker"}
FACTION.pay = 50
FACTION.isGloballyRecognized = true

FACTION_SHERIFF = FACTION.index
