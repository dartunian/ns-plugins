FACTION.name = "Townfolk"
FACTION.desc = "The average folk."
FACTION.color = Color(25, 180, 30)
FACTION.isDefault = true
FACTION.pay = 20

FACTION.models = {
	"models/humans/groupap/mapert_02.mdl",
	"models/humans/groupap/mapert_04.mdl",
	"models/humans/groupap/mapert_06.mdl",
	"models/humans/groupap/mapert_08.mdl"
}

FACTION_TOWNFOLK = FACTION.index