FACTION.name = "Native American"
FACTION.desc = "A person lost in today's modern society."
FACTION.color = Color(181, 111, 32)
FACTION.isDefault = true
FACTION.pay = 10
FACTION.weapons = {"weapon_huntingbow"}

FACTION.models = {
	"models/player/azw/zulu/zulu_npc.mdl"
}

FACTION_NATIVE = FACTION.index