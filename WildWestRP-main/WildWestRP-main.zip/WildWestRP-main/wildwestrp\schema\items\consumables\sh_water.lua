ITEM.name = "Water"
ITEM.model = "models/Gibs/HGIBS.mdl"
ITEM.desc = "Water."
ITEM.width = 1
ITEM.height = 1
ITEM.health = 5
ITEM.action = "drink"
ITEM.noBusiness = true