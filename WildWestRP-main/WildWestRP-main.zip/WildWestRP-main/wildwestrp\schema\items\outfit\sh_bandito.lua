ITEM.name = "Bandito Outfit"
ITEM.desc = "White shirt, brown vest and red-brown pants."
ITEM.outfitCategory = "outfit"
ITEM.category = "Clothes"
ITEM.price = 55
ITEM.flag = "d"
ITEM.model = "models/props_c17/BriefCase001a.mdl"
ITEM.replacement = "models/fof/bandito/bandito.mdl"
