
ITEM.name = ".50 Smith Ammo"
ITEM.price = 5
ITEM.model = "models/Items/BoxBuckshot.mdl"
ITEM.ammo = "ent_ww_ammo_50smith" // type of the ammo
ITEM.ammoAmount = 18 // amount of the ammo
ITEM.ammoDesc = "A Box of %s Smith Ammo."
ITEM.category = "Ammunition"
ITEM.flag = "y"