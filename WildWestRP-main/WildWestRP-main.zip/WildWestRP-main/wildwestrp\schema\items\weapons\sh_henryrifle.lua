

ITEM.name = "Henry Rifle"
ITEM.desc = "A semi-automatic rifle made of steel."
ITEM.model = "models/weapons/w_henryrifle.mdl"
ITEM.class = "weapon_fof_henry"
ITEM.weaponCategory = "primary"
ITEM.width = 4
ITEM.price = 300
ITEM.height = 2
ITEM.flag = "Y"
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}