
ITEM.name = "45. Schofield Ammo"
ITEM.model = "models/items/357ammo.mdl"
ITEM.price = 5
ITEM.ammo = "ent_ww_ammo_45schofield" // type of the ammo
ITEM.ammoAmount = 20 // amount of the ammo
ITEM.ammoDesc = "A Box that contains %s of Schofield Ammo."
ITEM.category = "Ammunition"
ITEM.flag = "y"