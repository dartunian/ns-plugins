ITEM.name = "Indiana Outfit"
ITEM.desc = "White shirt, dark brown jacket and brown pants."
ITEM.outfitCategory = "outfit"
ITEM.category = "Clothes"
ITEM.price = 50
ITEM.flag = "d"
ITEM.model = "models/props_c17/BriefCase001a.mdl"
ITEM.replacement = "models/player/indiana_jones.mdl"
