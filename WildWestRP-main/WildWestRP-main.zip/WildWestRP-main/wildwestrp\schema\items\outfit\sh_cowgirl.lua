ITEM.name = "Cowgirl Outfit"
ITEM.desc = "White shirt and black jeans."
ITEM.outfitCategory = "outfit"
ITEM.category = "Clothes"
ITEM.price = 100
ITEM.flag = "Y"
ITEM.model = "models/props_c17/BriefCase001a.mdl"
ITEM.replacement = "models/sadieadler/sadieadlerpm.mdl"
