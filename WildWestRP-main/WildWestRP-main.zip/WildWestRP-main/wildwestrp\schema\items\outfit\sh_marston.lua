ITEM.name = "Cowboy Outfit No. 1"
ITEM.desc = "White-brown shirt, dark green vest and dark green pants."
ITEM.outfitCategory = "outfit"
ITEM.category = "Clothes"
ITEM.price = 75
ITEM.flag = "d"
ITEM.model = "models/props_c17/BriefCase001a.mdl"
ITEM.replacement = "models/player/john_marston.mdl"
