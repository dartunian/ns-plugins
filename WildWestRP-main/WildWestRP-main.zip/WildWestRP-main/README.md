# WildWestRP
An old project of mine.
Set in the good old and pretty bad days of the Wild West, it was originally a request for someone but he ditched... $5 be too much :(
It also means I dont know where to find most of the addons required for this but I'm sure his workshop collection is still out there.
