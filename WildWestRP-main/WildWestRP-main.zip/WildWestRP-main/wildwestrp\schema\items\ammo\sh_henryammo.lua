

ITEM.name = ".44 Henry Ammo"
ITEM.price = 0
ITEM.model = "models/Items/BoxMRounds.mdl"
ITEM.ammo = "ent_ww_ammo_44henry" // type of the ammo
ITEM.ammoAmount = 24 // amount of the ammo
ITEM.ammoDesc = "A Box that contains %s of Henry Ammo"
ITEM.category = "Ammunition"
ITEM.flag = "Y"