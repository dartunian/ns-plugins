ITEM.name = "Beans"
ITEM.model = "models/props_lab/jar01a.mdl"
ITEM.desc = "Made in Texas."
ITEM.width = 1
ITEM.height = 1
ITEM.health = 15
ITEM.action = "eat"