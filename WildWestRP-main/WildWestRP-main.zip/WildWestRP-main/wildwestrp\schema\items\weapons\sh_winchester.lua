
ITEM.name = "Sawn of Winchester Model 1892"
ITEM.desc = "A powerful yet tiny shotgun."
ITEM.class = "weapon_fof_maresleg"
ITEM.weaponCategory = "primary"
ITEM.model = "models/weapons/w_maresleg.mdl"
ITEM.width = 3
ITEM.height = 1
ITEM.price = 275
ITEM.iconCam = {
    pos = Vector(0, 200, 1),
    ang = Angle(0, 270, 0),
    fov = 10
}
ITEM.flag = "y"
