
ITEM.name = ".45-70 Sharp Ammo"
ITEM.price = 5
ITEM.model = "models/Items/BoxBuckshot.mdl"
ITEM.ammo = "ent_ww_ammo_4570" // type of the ammo
ITEM.ammoAmount = 12 // amount of the ammo
ITEM.ammoDesc = "A Box of %s Sharp Ammo."
ITEM.category = "Ammunition"
ITEM.flag = "y"