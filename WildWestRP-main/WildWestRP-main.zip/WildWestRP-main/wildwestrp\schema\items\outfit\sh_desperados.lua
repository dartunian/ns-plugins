ITEM.name = "Desperados Outfit"
ITEM.desc = "Red shirt, brown coat and green pants."
ITEM.outfitCategory = "outfit"
ITEM.category = "Clothes"
ITEM.price = 45
ITEM.flag = "d"
ITEM.model = "models/props_c17/BriefCase001a.mdl"
ITEM.replacement = "models/fof/desperados/desperados.mdl"
