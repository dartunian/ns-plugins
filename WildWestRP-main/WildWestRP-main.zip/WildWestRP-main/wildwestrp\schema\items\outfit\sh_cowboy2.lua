ITEM.name = "Cowboy Outfit No. 2"
ITEM.desc = "Gray-blue shirt, brown vest and black pants."
ITEM.outfitCategory = "outfit"
ITEM.category = "Clothes"
ITEM.price = 70
ITEM.flag = "d"
ITEM.model = "models/props_c17/BriefCase001a.mdl"
ITEM.replacement = "models/player/chocolatfurry5/chocolatfurry5.mdl"
