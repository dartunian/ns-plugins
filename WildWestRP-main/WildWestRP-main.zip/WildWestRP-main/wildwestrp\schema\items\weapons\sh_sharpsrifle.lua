

ITEM.name = "Sharps Rifle 1873"
ITEM.desc = "A rifle made of steel and wood."
ITEM.model = "models/weapons/w_sharpp.mdl"
ITEM.class = "weapon_fof_sharps_noscope"
ITEM.weaponCategory = "primary"
ITEM.width = 4
ITEM.price = 250
ITEM.height = 2
ITEM.flag = "y"
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}