

ITEM.name = "Guitar"
ITEM.desc = "Utilizes the power of music."
ITEM.model = "models/custom/guitar/m_d_45.mdl"
ITEM.class = "guitar_western"
ITEM.weaponCategory = "Primary"
ITEM.price = 100
ITEM.width = 2
ITEM.height = 1
ITEM.flag = "Y"
ITEM.iconCam = {
	ang	= Angle(-17.581502914429, 250.7974395752, 0),
	fov	= 5.412494001838,
	pos	= Vector(57.109928131104, 181.7945098877, -60.738327026367)
}