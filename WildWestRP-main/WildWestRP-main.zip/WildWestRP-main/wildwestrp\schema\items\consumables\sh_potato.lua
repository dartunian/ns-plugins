ITEM.name = "Potato"
ITEM.model = "models/Gibs/HGIBS.mdl"
ITEM.desc = "Stolen from Johnny's yard."
ITEM.width = 1
ITEM.height = 1
ITEM.health = 15
ITEM.action = "eat"