function SCHEMA:PlayerSpray(client)
	return true
end