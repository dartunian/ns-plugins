ITEM.name = "Sheriff Outfit"
ITEM.desc = "A sheriff's black suit... Become the law."
ITEM.outfitCategory = "outfit"
ITEM.category = "Clothes"
ITEM.price = 50
ITEM.flag = "Y"
ITEM.model = "models/props_c17/BriefCase001a.mdl"
ITEM.replacement = "models/fof/ranger/ranger.mdl"
