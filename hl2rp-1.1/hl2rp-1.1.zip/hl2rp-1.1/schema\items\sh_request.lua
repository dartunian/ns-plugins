ITEM.name = "Request Device"
ITEM.desc = "A device used to communicate with Civil Protection."
ITEM.model = "models/gibs/shield_scanner_gib1.mdl"
ITEM.price = 25
ITEM.permit = "misc"