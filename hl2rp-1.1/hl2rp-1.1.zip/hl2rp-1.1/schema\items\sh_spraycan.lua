ITEM.name = "Spraycan"
ITEM.desc = "It rattles when you shake it."
ITEM.model = Model("models/props_junk/garbage_plasticbottle003a.mdl")
ITEM.price = 20
ITEM.permit = "misc"