ITEM.name = "Electronics Permit"
ITEM.desc = "A piece of paper that allows one to sell electronic goods."
ITEM.price = 150
ITEM.model = "models/props_lab/clipboard.mdl"
ITEM.category = "Permits"
ITEM.factions = {FACTION_CITIZEN}