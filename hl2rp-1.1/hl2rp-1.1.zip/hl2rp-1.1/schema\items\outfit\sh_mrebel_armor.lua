ITEM.name = "Resistance Medic Armor"
ITEM.desc = "Resistance clothing with a red cross on it."
ITEM.replacements = {
    {"group01", "group03m"},
    {"group02", "group03m"},
    {"group03", "group03m"},
}
ITEM.armor = 25
ITEM.price = 100
ITEM.flag = "y"