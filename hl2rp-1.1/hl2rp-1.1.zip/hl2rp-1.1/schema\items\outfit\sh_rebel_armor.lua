ITEM.name = "Resistance Armor"
ITEM.desc = "Clothing fit for the Resistance."
ITEM.replacements = {
    {"group01", "group03"},
    {"group02", "group03"},
    {"group03m", "group03"},
}
ITEM.armor = 25
ITEM.price = 100
ITEM.flag = "y"