FACTION.name = "fCitizenName"
FACTION.desc = "fCitizenDesc"
FACTION.color = Color(25, 180, 30)

FACTION_CITIZEN = FACTION.index