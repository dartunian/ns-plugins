ITEM.name = "Consumables Permit"
ITEM.desc = "A piece of paper that allows one to sell consumable goods."
ITEM.price = 300
ITEM.model = "models/props_lab/clipboard.mdl"
ITEM.category = "Permits"
ITEM.factions = {FACTION_CITIZEN}