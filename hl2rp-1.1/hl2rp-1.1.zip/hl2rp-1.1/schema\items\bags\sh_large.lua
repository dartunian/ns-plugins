ITEM.name = "Large Bag"
ITEM.desc = "A big bag capable of holding a lot of items."
ITEM.price = 125
ITEM.invWidth = 4
ITEM.invHeight = 3
ITEM.permit = "misc"