FACTION.name = "fAdminName"
FACTION.desc = "fAdminDesc"
FACTION.color = Color(237, 179, 97)
FACTION.isDefault = false
FACTION.models = {
	"models/breen.mdl"
}
FACTION.pay = 40
FACTION.isGloballyRecognized = true

FACTION_ADMIN = FACTION.index